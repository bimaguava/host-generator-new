#!/bin/bash
mkdir temp-cfg
cat  nagios-windows.csv | while read LINE
do
	HostIP=`echo $LINE | cut -d, -f1`
	HostName=`echo $LINE | cut -d, -f2`
	sed -e "s/XXXX/$HostName/g; s/ZZZZ/$HostIP/g" Nagios-Template-Win.cfg > temp-cfg/$HostName.cfg
done

